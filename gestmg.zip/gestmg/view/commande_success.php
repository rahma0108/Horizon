<?php
require_once __DIR__ . '/../vendor/autoload.php';
session_start();

// Stripe Secret Key
\Stripe\Stripe::setApiKey('sk_test_51RKqweGg9HTHVphnerNJMxcyUS79RSsalU21GhcW3l5IBC9B1MyLoQnqgwbQPN8CqDZrTSLdwxZH6bfdeo3GAh9e006Ne3ESSL');

// Validate session and order
if (!isset($_GET['session_id']) || !isset($_SESSION['order_data'])) {
    die("❌ Paiement invalide ou session expirée.");
}

// Verify Stripe session
$session_id = $_GET['session_id'];
$stripe = new \Stripe\StripeClient(\Stripe\Stripe::getApiKey());
$checkoutSession = $stripe->checkout->sessions->retrieve($session_id);

if ($checkoutSession->payment_status !== 'paid') {
    die("❌ Paiement non confirmé.");
}

// Retrieve order data from session
$order = $_SESSION['order_data'];
unset($_SESSION['order_data']); // Optional: clear after success
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Commande Réussie</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f0fdf4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .confirmation-box {
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            text-align: center;
            max-width: 600px;
        }
        h1 {
            color: #16a34a;
            font-size: 28px;
        }
        p {
            font-size: 16px;
            margin: 8px 0;
        }
        .btn {
            display: inline-block;
            margin-top: 20px;
            background: #c5ff38;
            color: #000;
            padding: 12px 20px;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="confirmation-box">
        <h1>🎉 Paiement réussi !</h1>
        <p><strong>Produit :</strong> ID <?= htmlspecialchars($order['id_produit']) ?></p>
        <p><strong>Quantité :</strong> <?= $order['quantite'] ?></p>
        <p><strong>Taille :</strong> <?= htmlspecialchars($order['taille']) ?></p>
        <p><strong>Nom :</strong> <?= htmlspecialchars($order['nom_client']) ?></p>
        <p><strong>Adresse :</strong> <?= nl2br(htmlspecialchars($order['adresse'])) ?></p>
        <p><strong>Total payé :</strong> <?= number_format($order['total'], 2) ?> €</p>

        <a class="btn" href="front.php">🔙 Retour à la boutique</a>
    </div>
</body>
</html>
